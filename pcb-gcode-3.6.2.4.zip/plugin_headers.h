#include "source/nonvolatile.h"

#include "plugins/settings.plugin.h"
#include "plugins/calculator.plugin.h"
 